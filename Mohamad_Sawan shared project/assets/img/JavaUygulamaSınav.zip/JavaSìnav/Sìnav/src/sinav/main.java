package sinav;

public class main {

	public static void main(String[] args) {
		mudur mdr = new mudur();
		satiselemani satis = new satiselemani();
		
		satis.ad = "Huso";
		satis.soyad = "Kurt";
		satis.birim = "bilişim";
		satis.görev = "yazılım";
		satis.maas = 5000;
		
		mdr.zamyap(2000);
		
		personel.bilgilerigetir();
		
	}

}
