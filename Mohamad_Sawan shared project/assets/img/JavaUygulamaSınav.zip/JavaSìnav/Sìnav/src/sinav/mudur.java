package sinav;

public class mudur extends personel{
	 
	public int zamyap(int ekle){
		mudur.maas = mudur.maas+ekle;
		return mudur.maas;
	}
}
