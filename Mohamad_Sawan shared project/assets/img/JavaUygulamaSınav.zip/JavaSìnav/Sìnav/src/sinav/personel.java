package sinav;

public class personel {
	static private String tcno = "35067879845";
    static public String ad = "";
	static public String soyad = "";
	static public String birim = "";
    static public String görev = "";
    static public int maas = 0;
	static public String gettcno(){
		return tcno;
	}
	static public void bilgilerigetir() {
		personel nesne = new personel();
		System.out.println("adınız: "+nesne.ad+"\nsoyadınız: "+nesne.soyad+"\nbiriminiz: "+nesne.birim+"\ngöreviniz: "+nesne.görev+"\nmaaşınız: "+nesne.maas);
	}
}
