package sinav;

public class satiselemani extends personel{

}
